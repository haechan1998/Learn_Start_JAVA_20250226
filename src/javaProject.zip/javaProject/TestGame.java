package javaProject;

import java.io.IOException;

public class TestGame {

	public static void main(String[] args) throws IOException {
		
		MiniGame m = new MiniGame();
		m.memoryGame();
		m.bingoGame();
	}

}
