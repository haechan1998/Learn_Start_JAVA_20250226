package project1;

public class CardMain {

	public static void main(String[] args) throws InterruptedException {
		ConsoleView c = new ConsoleView();
		new GameController().startGame();

	}

}
